﻿using System;
using System.Collections.Generic;
using System.Text;

namespace App7.Models
{
    public class Volume
    {
        public int water { get; set; }
        
    }
}
