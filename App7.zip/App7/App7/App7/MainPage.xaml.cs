﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using Rg.Plugins.Popup.Services;
using App7.Models;

namespace App7
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage 
    {
        
        public MainPage()
        {

            InitializeComponent();
            Volume volume = new Volume();
            volume.water = 0;
            BindingContext = volume;

        }

        private async void image1(object sender, EventArgs e)
        {
            await PopupNavigation.Instance.PushAsync(new PopupView());

        }

        private async void image2(object sender, EventArgs e)
        {
            await PopupNavigation.Instance.PushAsync(new PopupView1());
        }

        private async void image3(object sender, EventArgs e)
        {
            await PopupNavigation.Instance.PushAsync(new PopupView2());
        }

        private async void image4(object sender, EventArgs e)
        {

            await PopupNavigation.Instance.PushAsync(new PopupView3());
        }
    }
}
