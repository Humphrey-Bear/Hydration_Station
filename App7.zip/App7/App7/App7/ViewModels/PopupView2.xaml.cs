﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rg.Plugins.Popup.Services;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace App7
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PopupView2 
    {
        public PopupView2()
        {
            InitializeComponent();
        }

        public static int result2 { get; set; } = 0;
     
        public async void pop1(object sender, EventArgs e)
        {
            result2 += 250;
            string myString = result2.ToString();
            yeet.Text = "" + myString;
            await PopupNavigation.PopAsync(true);
        }

        public async void pop2(object sender, EventArgs e)
        {
            result2 += 500;
            string myString = result2.ToString();
            yeet.Text = "" + myString;
            await PopupNavigation.PopAsync(true);
        }

        public async void pop3(object sender, EventArgs e)
        {
            result2 += 1000;
            string myString = result2.ToString();
            yeet.Text = "" + myString;
            await PopupNavigation.PopAsync(true);
        }
        

        public async void enter(object sender, EventArgs e)
        {

            string text = Amount.Text;
            int result = Int32.Parse(text);
            result2 += result;

            string myString = result2.ToString();
            yeet.Text = "" + myString;
            await PopupNavigation.PopAsync(true);

        }
    }
}